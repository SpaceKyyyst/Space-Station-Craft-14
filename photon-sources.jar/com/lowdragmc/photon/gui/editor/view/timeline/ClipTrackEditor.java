package com.lowdragmc.photon.gui.editor.view.timeline;

import com.lowdragmc.lowdraglib2.configurator.IConfigurable;
import com.lowdragmc.lowdraglib2.configurator.ui.BooleanConfigurator;
import com.lowdragmc.lowdraglib2.configurator.ui.ConfiguratorGroup;
import com.lowdragmc.lowdraglib2.configurator.ui.NumberConfigurator;
import com.lowdragmc.lowdraglib2.gui.ColorPattern;
import com.lowdragmc.lowdraglib2.gui.sync.bindings.impl.SupplierDataSource;
import com.lowdragmc.lowdraglib2.gui.texture.GuiTexture;
import com.lowdragmc.lowdraglib2.gui.texture.Icons;
import com.lowdragmc.lowdraglib2.gui.ui.UIElement;
import com.lowdragmc.lowdraglib2.gui.ui.elements.Label;
import com.lowdragmc.lowdraglib2.gui.ui.event.UIEvent;
import com.lowdragmc.lowdraglib2.gui.ui.event.UIEvents;
import com.lowdragmc.lowdraglib2.gui.ui.rendering.GUIContext;
import com.lowdragmc.lowdraglib2.gui.util.DrawerHelperClient;
import com.lowdragmc.lowdraglib2.gui.util.TreeBuilder;
import com.lowdragmc.photon.client.fx.timeline.Clip;
import com.lowdragmc.photon.client.fx.timeline.Track;
import dev.vfyjxf.taffy.style.TaffyPosition;
import net.minecraft.network.chat.Component;

import javax.annotation.Nullable;

/**
 * Shared base for clip-based tracks (activator, control): the lane with draggable / edge-resizable
 * clips, snapping, overlap rejection, selection and the clip inspector. Subclasses provide the header
 * content and the per-type clip creation / labelling / menu.
 */
public abstract class ClipTrackEditor extends TrackEditor {
    private static final int DRAG_MOVE = 0;
    private static final int DRAG_LEFT = 1;
    private static final int DRAG_RIGHT = 2;

    /** Per-clip-track transient drag state. */
    public static class ClipTrackUIState extends TrackUIState {
        @Nullable Clip draggingClip;
        int dragMode = DRAG_MOVE;
        double grabOffsetTicks, dragFixedEnd, dragBeforeStart, dragBeforeDuration;
        boolean dragInvalid;
        /** True while this clip element drives a host group drag (multi-selection move). */
        boolean groupDrag;
    }

    @Override
    public ClipTrackUIState createState() {
        return new ClipTrackUIState();
    }

    /** Translucent clip fill color (border uses {@link #chipColor()}). */
    public abstract ColorPattern clipFillColor();

    /** Optional label drawn inside a clip (e.g. the bound object's name for control clips). */
    @Nullable
    protected String clipLabel(TimelineContext ctx, Track track, Clip clip) {
        return null;
    }

    /** Right-click on an empty part of the lane. */
    protected void onLaneRightClick(TimelineContext ctx, Track track, float x, float y) {
    }

    /** Double-click on an empty part of the lane. */
    protected void onLaneDoubleClick(TimelineContext ctx, Track track, float x, float y) {
    }

    /** A drag dropped onto the lane (e.g. an fx object dragged onto a control lane). */
    protected void onLaneDrop(TimelineContext ctx, Track track, UIEvent event) {
    }

    /** Extra clip context-menu entries (e.g. control seed options). */
    protected void buildClipMenu(TreeBuilder.Menu menu, TimelineContext ctx, Track track, Clip clip) {
    }

    /** Extra clip inspector configurators (e.g. control seed/randomSeed). */
    protected void buildClipConfigurator(ConfiguratorGroup group,
                                         TimelineContext ctx, Track track, Clip clip) {
    }

    /** Draw extra decoration inside a clip (over the fill/border), e.g. audio loop sub-divisions.
     *  {@code x/y/w/h} are the clip's inner rect. Default no-op. */
    protected void drawClipDecoration(GUIContext graphics, TimelineContext ctx, Track track, Clip clip,
                                      float x, float y, float w, float h, float pt) {
    }

    @Override
    public double contentMaxTick(Track track) {
        double max = 0;
        for (var clip : track.clips()) {
            max = Math.max(max, clip.end());
        }
        return max;
    }

    @Override
    public boolean deleteSelection(TimelineContext ctx, Track track, TrackUIState state) {
        var clip = ctx.selectedClip();
        if (clip != null && ctx.selectedClipTrack() == track) {
            if (track.lock()) return true; // selection consumed, but locked
            ctx.editor().inspectorView.clear();
            ctx.removeClip(track, clip);
            return true;
        }
        return false;
    }

    @Override
    public UIElement buildLane(TimelineContext ctx, Track track, TrackUIState state) {
        var lane = new UIElement().setId("timeline.trackLane").layout(layout -> {
            layout.widthPercent(100);
            layout.height(state.rowHeight);
        }).setOverflowVisible(false).style(style -> style
                .backgroundTexture(GuiTexture.of((graphics, x, y, w, h) -> {
                    DrawerHelperClient.drawSolidRect(graphics, x, y, w, h, ColorPattern.BLACK.color);
                    if (ctx.isTrackSelected(track)) {
                        DrawerHelperClient.drawSolidRect(graphics, x, y, w, h, ColorPattern.T_WHITE.color);
                    }
                    if (track.mute()) {
                        DrawerHelperClient.drawSolidRect(graphics, x, y, w, h, ColorPattern.T_RED.color);
                    } else if (track.lock()) {
                        DrawerHelperClient.drawSolidRect(graphics, x, y, w, h, ColorPattern.T_YELLOW.color);
                    }
                }))
                .overlayTexture(GuiTexture.of((graphics, x, y, w, h) -> ctx.drawPlayhead(graphics, x, y, w, h, graphics.partialTick))));
        lane.addEventListener(UIEvents.MOUSE_WHEEL, ctx::zoom);
        lane.addEventListener(UIEvents.MOUSE_DOWN, e -> {
            if (e.button == 0) {
                if (!e.isShiftDown()) ctx.selectTrack(track); // shift = additive marquee (don't clear)
            } else if (e.button == 1 && !track.lock()) {
                onLaneRightClick(ctx, track, e.x, e.y);
            }
        });
        lane.addEventListener(UIEvents.DOUBLE_CLICK, e -> {
            if (!track.lock()) onLaneDoubleClick(ctx, track, e.x, e.y);
        });
        lane.addEventListener(UIEvents.DRAG_PERFORM, e -> onLaneDrop(ctx, track, e));
        for (var clip : track.clips()) {
            lane.addChild(createClipElement(ctx, track, (ClipTrackUIState) state, clip));
        }
        return lane;
    }

    private UIElement createClipElement(TimelineContext ctx, Track track, ClipTrackUIState st, Clip clip) {
        var baseColor = chipColor();
        var fillColor = clipFillColor();
        var clipHeight = st.rowHeight - 6;
        var element = new UIElement().setId("timeline.clip").layout(layout -> {
            layout.positionType(TaffyPosition.ABSOLUTE);
            layout.left(ctx.tickToLocalX(clip.start()));
            layout.top((st.rowHeight - clipHeight) / 2f);
            layout.width((float) Math.max(2, clip.duration() * ctx.scale()));
            layout.height(clipHeight);
            layout.paddingAll(2);
        }).style(style -> style
                .backgroundTexture(GuiTexture.of((graphics, x, y, w, h) -> {
                    var invalid = clipDragInvalid(ctx, st, clip);
                    DrawerHelperClient.drawSolidRect(graphics, x + 1, y, Math.max(1, w - 2), h,
                            (invalid ? ColorPattern.T_RED : fillColor).color);
                }))
                .overlayTexture(GuiTexture.of((graphics, x, y, w, h) -> {
                    var bx = x + 1;
                    var bw = Math.max(1, w - 2);
                    var invalid = clipDragInvalid(ctx, st, clip);
                    DrawerHelperClient.drawBorder(graphics, bx, y, bw, h, (invalid ? ColorPattern.RED : baseColor).color, 1);
                    if (ctx.isClipSelected(clip) && !invalid) {
                        DrawerHelperClient.drawBorder(graphics, bx, y, bw, h, ColorPattern.WHITE.color, 1);
                    }
                    drawClipDecoration(graphics, ctx, track, clip, bx, y, bw, h, graphics.partialTick);
                    if (!track.lock() && graphics.mouseY >= y && graphics.mouseY <= y + h && (graphics.mouseX <= bx + TimelineContext.EDGE_PX || graphics.mouseX >= bx + bw - TimelineContext.EDGE_PX)
                            && graphics.mouseX >= bx && graphics.mouseX <= bx + bw) {
                        graphics.drawTexture(Icons.ARROW_LEFT_RIGHT, graphics.mouseX - 5, graphics.mouseY - 5, 10, 10);
                    }
                })));
        ctx.registerClipView(track, clip, element);

        if (clipLabel(ctx, track, clip) != null) {
            // bind to a live data source so the label follows the latest value (e.g. a changed sound)
            // without needing a rebuild; a supplier that returns null keeps the last shown text
            var labelEl = new Label().bindDataSource(
                    SupplierDataSource.of(() -> {
                        var text = clipLabel(ctx, track, clip);
                        return Component.literal(text == null ? "" : text);
                    }));
            TimelineContext.styleLabel(labelEl);
            labelEl.layout(layout -> layout.flex(1).heightPercent(100));
            element.addChild(labelEl);
        }

        element.addEventListener(UIEvents.MOUSE_DOWN, e -> {
            if (e.button == 1) {
                ctx.selectClip(track, clip);
                if (!track.lock()) {
                    var menu = TreeBuilder.Menu.start();
                    buildClipMenu(menu, ctx, track, clip);
                    menu.leaf("ldlib.gui.editor.menu.remove", () -> ctx.removeClip(track, clip));
                    ctx.openMenu(e.x, e.y, menu);
                }
                e.stopPropagation();
                return;
            }
            // Ctrl/Shift-click toggles this clip in the multi-selection (no drag)
            if (e.isShiftDown() || e.isCtrlDown()) {
                ctx.toggleClipSelection(track, clip);
                e.stopPropagation();
                return;
            }
            // keep the multi-selection when grabbing one of its members; otherwise select just this clip
            var inGroup = ctx.selectedClips().size() > 1 && ctx.selectedClips().contains(clip);
            if (!inGroup) ctx.selectClip(track, clip);
            if (track.lock()) {
                e.stopPropagation();
                return;
            }
            var localX = e.x - element.getPositionX();
            var w = element.getSizeWidth();
            st.dragMode = localX <= TimelineContext.EDGE_PX ? DRAG_LEFT : (localX >= w - TimelineContext.EDGE_PX ? DRAG_RIGHT : DRAG_MOVE);
            var grab = ctx.xToTick(e.x) - clip.start();
            if (st.dragMode == DRAG_MOVE) { // unified: single or multi move goes through the host group drag
                st.groupDrag = true;
                ctx.beginClipGroupDrag(clip, grab);
                element.startDrag(null, null);
                e.stopPropagation();
                return;
            }
            st.grabOffsetTicks = grab;
            st.dragFixedEnd = clip.end();
            st.dragBeforeStart = clip.start();
            st.dragBeforeDuration = clip.duration();
            st.draggingClip = clip;
            st.dragInvalid = false;
            ctx.setDragGuide(clip);
            ctx.beginScrub();
            element.startDrag(null, null);
            e.stopPropagation();
        });
        element.addEventListener(UIEvents.DRAG_SOURCE_UPDATE, e -> {
            if (st.groupDrag) { ctx.updateClipGroupDrag(e.x, e.y, e.isCtrlDown()); e.stopPropagation(); return; }
            var ctrl = e.isCtrlDown();
            var cursorTick = ctx.xToTick(e.x);
            if (st.dragMode == DRAG_RIGHT) {
                var end = ctx.snapTick(cursorTick, clip, ctrl);
                clip.duration(Math.max(1, Math.round(end - clip.start())));
            } else if (st.dragMode == DRAG_LEFT) {
                var start = ctx.snapTick(cursorTick - st.grabOffsetTicks, clip, ctrl);
                start = Math.max(0, Math.min(start, st.dragFixedEnd - 1));
                clip.start(Math.round(start));
                clip.duration(Math.max(1, Math.round(st.dragFixedEnd - clip.start())));
            } else {
                var start = ctx.snapMoveStart(cursorTick - st.grabOffsetTicks, clip.duration(), clip, ctrl);
                clip.start(Math.max(0, Math.round(start)));
            }
            st.dragInvalid = overlaps(track, clip);
            applyClipLayout(ctx, element, clip);
            ctx.refreshPreview();
        });
        element.addEventListener(UIEvents.DRAG_END, e -> {
            if (st.groupDrag) { st.groupDrag = false; ctx.endClipGroupDrag(true); e.stopPropagation(); return; }
            st.draggingClip = null;
            ctx.setDragGuide(null);
            ctx.endScrub();
            var beforeStart = st.dragBeforeStart;
            var beforeDuration = st.dragBeforeDuration;
            if (st.dragInvalid) {
                st.dragInvalid = false;
                clip.start(beforeStart).duration(beforeDuration);
                applyClipLayout(ctx, element, clip);
                ctx.refreshPreview();
            } else {
                var afterStart = clip.start();
                var afterDuration = clip.duration();
                if (beforeStart != afterStart || beforeDuration != afterDuration) {
                    ctx.pushApplied("photon.gui.editor.timeline.edit_clip",
                            () -> { clip.start(afterStart).duration(afterDuration); ctx.requestRebuild(); ctx.refreshPreview(); },
                            () -> { clip.start(beforeStart).duration(beforeDuration); ctx.requestRebuild(); ctx.refreshPreview(); });
                }
            }
        });
        return element;
    }

    /** Red-feedback flag for a clip: a single-clip resize that overlaps, or a member of an invalid
     *  group drag. (MOVE drags are unified through the host group path, single = a 1-clip group.) */
    private boolean clipDragInvalid(TimelineContext ctx, ClipTrackUIState st, Clip clip) {
        if (st.draggingClip == clip && st.dragInvalid) return true;
        return ctx.isClipGroupDragInvalid() && ctx.isClipSelected(clip);
    }

    /** Whether two clips conflict on the same lane. Base = any time-overlap; control overrides to only
     *  conflict with same-target clips. Shared by single-clip resize and group-move validation. */
    public boolean clipsConflict(Clip a, Clip b) {
        return a.start() < b.end() && b.start() < a.end();
    }

    /** Whether {@code clip} overlaps another clip on the same lane. */
    protected boolean overlaps(Track track, Clip clip) {
        for (var other : track.clips()) {
            if (other == clip) continue;
            if (clipsConflict(clip, other)) return true;
        }
        return false;
    }

    private void applyClipLayout(TimelineContext ctx, UIElement element, Clip clip) {
        element.layout(layout -> {
            layout.left(ctx.tickToLocalX(clip.start()));
            layout.width((float) Math.max(2, clip.duration() * ctx.scale()));
        });
    }

    @Override
    public IConfigurable trackConfigurator(TimelineContext ctx, Track track) {
        return IConfigurable.create(group -> {
            buildHeaderConfigurator(group, ctx, track);
            group.addConfigurator(new BooleanConfigurator("mute", track::mute,
                    v -> { track.mute(v); ctx.requestRebuild(); ctx.refreshPreview(); }, track.mute(), true));
            group.addConfigurator(new BooleanConfigurator("lock", track::lock,
                    v -> { track.lock(v); ctx.requestRebuild(); }, track.lock(), true));
        });
    }

    /** Extra track configurators above mute/lock (e.g. the control track name). */
    protected void buildHeaderConfigurator(ConfiguratorGroup group,
                                           TimelineContext ctx, Track track) {
    }

    /** Build the clip inspector (start/duration + per-type extras). */
    public IConfigurable clipConfigurator(TimelineContext ctx, Track track, Clip clip) {
        return IConfigurable.create(group -> {
            group.addConfigurator(new NumberConfigurator("start", clip::start,
                    v -> { clip.start(Math.max(0, v.doubleValue())); ctx.requestRebuild(); ctx.refreshPreview(); },
                    clip.start(), true).setRange(0, 1_000_000));
            group.addConfigurator(new NumberConfigurator("duration", clip::duration,
                    v -> { clip.duration(Math.max(1, v.doubleValue())); ctx.requestRebuild(); ctx.refreshPreview(); },
                    clip.duration(), true).setRange(1, 1_000_000));
            buildClipConfigurator(group, ctx, track, clip);
        });
    }
}
