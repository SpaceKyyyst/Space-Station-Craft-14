package com.lowdragmc.photon.client;

import com.lowdragmc.lowdraglib2.gui.texture.IGuiTexture;
import com.lowdragmc.lowdraglib2.gui.texture.Icons;
import com.lowdragmc.lowdraglib2.gui.texture.SpriteTexture;
import com.lowdragmc.photon.Photon;

public final class PhotonIcons {
    public static final SpriteTexture LOCK = Icons.icon(Photon.MOD_ID, "lock");
    public static final SpriteTexture UNLOCK = Icons.icon(Photon.MOD_ID, "unlock");
    public static final SpriteTexture SHADER_GRAPH = Icons.icon(Photon.MOD_ID, "shadergraph");
    public static final SpriteTexture FULL_SCREEN_GRAPH = Icons.icon(Photon.MOD_ID, "fullscreengraph");
    public static final SpriteTexture SHADER_GRAPH_FUNCTION = Icons.icon(Photon.MOD_ID, "shadergraph_function");
    public static final IGuiTexture SHAPE_OUTLINE = Icons.icon(Photon.MOD_ID, "shape_outline");
    public static final IGuiTexture CULL_BOX = Icons.icon(Photon.MOD_ID, "cull_box");
    public static final IGuiTexture DRAW_SHADED = Icons.icon(Photon.MOD_ID, "draw_shaded");
    public static final IGuiTexture DRAW_WIREFRAME = Icons.icon(Photon.MOD_ID, "draw_wireframe");
    public static final IGuiTexture DRAW_BOTH = Icons.icon(Photon.MOD_ID, "draw_both");
    public static final IGuiTexture BLOOM = Icons.icon(Photon.MOD_ID, "bloom");
    public static final IGuiTexture LOOP = Icons.icon(Photon.MOD_ID, "loop");
    public static final IGuiTexture TIMELINE_END = Icons.icon(Photon.MOD_ID, "timeline_end");
    public static final IGuiTexture MARKER = Icons.icon(Photon.MOD_ID, "marker");
    public static final IGuiTexture RECORDING = Icons.icon(Photon.MOD_ID, "recording");
    public static final IGuiTexture PHOTON_PROJECT = Icons.icon(Photon.MOD_ID, "photon_project");

    // Timeline transport, in the order they sit on the bar.
    public static final SpriteTexture TRANSPORT_TO_START = Icons.icon(Photon.MOD_ID, "transport_to_start");
    public static final SpriteTexture TRANSPORT_STEP_BACK = Icons.icon(Photon.MOD_ID, "transport_step_back");
    public static final SpriteTexture TRANSPORT_PLAY = Icons.icon(Photon.MOD_ID, "transport_play");
    public static final SpriteTexture TRANSPORT_PAUSE = Icons.icon(Photon.MOD_ID, "transport_pause");
    public static final SpriteTexture TRANSPORT_STEP_FORWARD = Icons.icon(Photon.MOD_ID, "transport_step_forward");
    public static final SpriteTexture TRANSPORT_TO_END = Icons.icon(Photon.MOD_ID, "transport_to_end");
}
