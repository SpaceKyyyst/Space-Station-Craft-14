package com.lowdragmc.photon.client.postfx.runtime;

import com.lowdragmc.kilagraph.rendertype.RenderTypeGraphTypes;
import com.lowdragmc.kilagraph.rendertype.compiler.GlslType;
import com.lowdragmc.lowdraglib2.editor.resource.IResourcePath;
import com.lowdragmc.photon.client.postfx.graph.SizeSpec;
import com.lowdragmc.photon.client.postfx.graph.TargetFormat;
import com.lowdragmc.photon.client.postfx.shadergraph.FullscreenShaderGraph;
import com.lowdragmc.photon.client.postfx.shadergraph.runtime.FullscreenGraphRuntime;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * One effect, compiled to a flat execution plan: topologically ordered fullscreen passes over
 * transient resources with first/last-use lifetimes (the pool aliases inside those windows), plus the
 * effect's parameter schema (blackboard defaults + lerpability) for weight blending. Phase 2's render
 * graph compiler produces these; until then {@link #singlePass} adapts a bare fullscreen graph into a
 * one-pass effect.
 *
 * <p>Pass values bind explicitly: {@link ValueBinding.Constant} (an inline value authored on the
 * pass node), {@link ValueBinding.ParamRef} (a blackboard parameter of the effect, blended across
 * requests by weight), or {@link ValueBinding.EffectWeight} (the blended request weight itself,
 * wired from the render graph's Effect Weight node). The executor's auto final mix uses the same
 * weight regardless of whether any pass reads it.</p>
 */
public record CompiledEffect(
        IResourcePath source,
        int priority,
        boolean autoBlend,
        List<ParamSpec> schema,
        List<ResourceDesc> resources,
        List<CompiledPass> passes,
        int outputResource) {

    /** In a BARE fullscreen graph played directly (the {@link #singlePass} adapter — there is no
     *  render graph to wire the Effect Weight node in), a float variable with this exact name
     *  receives the blended request weight. Render-graph effects wire the node explicitly instead;
     *  their pass graphs treat "Weight" as an ordinary variable. */
    public static final String WEIGHT_PARAM = "Weight";

    /** The default priority of a bare fullscreen graph played as an effect (after builtin bloom = 0). */
    public static final int DEFAULT_PRIORITY = 100;

    /** Reserved request-param name enabling CustomMask culling on ANY effect. Value = the mask
     *  GROUP NAME string ("" = any group; absent = fullscreen). The stack's auto final mix becomes
     *  {@code mix(scene, effect, weight * match(mask))} — no graph work. A graph that declares a
     *  float param with this SAME name instead receives the resolved group id and handles the
     *  masking itself ({@link #declaresMaskFilter}). */
    public static final String MASK_FILTER_PARAM = "MaskFilter";

    /** Whether the schema declares the reserved MaskFilter param — "the graph matches the mask
     *  itself" (needed when the effect draws OUTSIDE the mask, e.g. outlines): the stack injects
     *  the resolved group id and skips the universal mix culling. */
    public boolean declaresMaskFilter() {
        for (var spec : schema) {
            if (MASK_FILTER_PARAM.equals(spec.name())) return true;
        }
        return false;
    }

    /** Reserved request-param name (Boolean): an independent request skips the per-effect
     *  dedup/merge and runs its OWN fullscreen execution with its own params/weight/mask filter
     *  (UE-material-instance-style) — the REQUESTER opts into the extra cost, not the asset. */
    public static final String INDEPENDENT_PARAM = "Independent";

    /** Whether any pass reads the CustomMask/CustomDepth inputs — lets the pipeline skip the mask
     *  sub-pass when no pending effect (and no MaskFilter request) would consume it. */
    public boolean usesCustomMask() {
        return readsAny(ResourceRef.Source.CUSTOM_MASK, ResourceRef.Source.CUSTOM_DEPTH);
    }

    /** Whether any pass reads the scene depth — the chain only pays for a sampleable copy of it when
     *  something asks (the render target's own depth view is not always bindable as a texture). */
    public boolean usesSceneDepth() {
        return readsAny(ResourceRef.Source.SCENE_DEPTH);
    }

    private boolean readsAny(ResourceRef.Source... sources) {
        for (var pass : passes) {
            for (var ref : pass.textures().values()) {
                for (var source : sources) {
                    if (ref.source() == source) return true;
                }
            }
        }
        return false;
    }

    /** One blendable effect parameter: the graph variable's display name, its declared default, and
     *  whether requests lerp it by weight (floats/vectors/colors) or take the highest-weight value. */
    public record ParamSpec(String name, @Nullable Object defaultValue, boolean lerpable) {}

    /** One transient render target: sizing rule + format + the pass-index window it must live for. */
    public record ResourceDesc(SizeSpec size, TargetFormat format, int firstUsePass, int lastUsePass,
                               String debugName) {}

    /** What a pass's texture input binds to. {@code asset} carries a baked image (ASSET); {@code param}
     *  names an effect sampler parameter resolved from the request at execution (PARAM). Both come from
     *  the render graph's {@code TextureInputNode}. */
    public record ResourceRef(Source source, int resource,
                              @Nullable RenderTypeGraphTypes.Sampler2DValue asset, @Nullable String param) {
        public enum Source { SCENE_COLOR, SCENE_DEPTH, CUSTOM_MASK, CUSTOM_DEPTH, RESOURCE, ASSET, PARAM }

        public static final ResourceRef SCENE_COLOR_REF = new ResourceRef(Source.SCENE_COLOR, -1, null, null);
        public static final ResourceRef SCENE_DEPTH_REF = new ResourceRef(Source.SCENE_DEPTH, -1, null, null);
        /** The pipeline's CustomMask target (flat mask ids of flagged FX passes; -1 when none). */
        public static final ResourceRef CUSTOM_MASK_REF = new ResourceRef(Source.CUSTOM_MASK, -1, null, null);
        /** The mask target's own depth (= the flagged passes' custom depth). */
        public static final ResourceRef CUSTOM_DEPTH_REF = new ResourceRef(Source.CUSTOM_DEPTH, -1, null, null);

        public static ResourceRef of(int resource) {
            return new ResourceRef(Source.RESOURCE, resource, null, null);
        }

        /** A fixed image baked into the effect (Texture Input node, Asset mode). */
        public static ResourceRef asset(RenderTypeGraphTypes.Sampler2DValue texture) {
            return new ResourceRef(Source.ASSET, -1, texture, null);
        }

        /** An effect sampler parameter supplied per request (Texture Input node, Parameter mode). */
        public static ResourceRef param(String name) {
            return new ResourceRef(Source.PARAM, -1, null, name);
        }
    }

    /** How a pass's exposed-variable value is sourced at execution. */
    public sealed interface ValueBinding {
        /** An inline value authored on the pass node. */
        record Constant(Object value) implements ValueBinding {}

        /** A blackboard parameter of the effect — blended across requests by weight. */
        record ParamRef(String schemaParam) implements ValueBinding {}

        /** The effect's blended request weight (0..1) itself — the Effect Weight node's output. */
        record EffectWeight() implements ValueBinding {
            public static final EffectWeight INSTANCE = new EffectWeight();
        }
    }

    /**
     * One fullscreen dispatch: its source is EITHER a pass graph (resolved through
     * {@code FullscreenGraphRuntime} at execution, so edits stay live) OR a hand-written core
     * shader (resolved through {@code CustomShaderPass}); texture bindings are keyed by
     * <b>sampler uniform name</b>, value bindings by <b>variable/uniform display name</b>.
     */
    public record CompiledPass(
            @Nullable IResourcePath graphPath,
            @Nullable String customShader,
            Map<String, ResourceRef> textures,
            Map<String, ValueBinding> params,
            int outputResource) {}

    /**
     * Adapt one fullscreen graph into a single-pass effect: scene color feeds the graph's
     * {@code Input} sampler variable (or its alphabetically-first one), the pass writes a full-screen
     * target that becomes the chain output. Returns null when the graph is broken.
     */
    @Nullable
    public static CompiledEffect singlePass(IResourcePath graphPath, FullscreenGraphRuntime.Entry entry) {
        var compiled = entry.getCompiled();
        if (compiled == null) return null;

        var textures = new LinkedHashMap<String, ResourceRef>();
        // display name -> sampler uniform; prefer the starter graph's "Input", else deterministic first
        var samplers = new TreeMap<>(compiled.variableSamplers());
        String inputName = samplers.containsKey(FullscreenShaderGraph.DEFAULT_INPUT)
                ? FullscreenShaderGraph.DEFAULT_INPUT
                : (samplers.isEmpty() ? null : samplers.firstKey());
        if (inputName != null) {
            textures.put(samplers.get(inputName), ResourceRef.SCENE_COLOR_REF);
        }

        // every exposed uniform IS an effect parameter here (schema names == variable names),
        // except WEIGHT_PARAM: with no render graph to wire the Effect Weight node in, a variable
        // by that name binds the request weight directly (and stays out of the blendable schema)
        var schema = new ArrayList<ParamSpec>();
        var params = new LinkedHashMap<String, ValueBinding>();
        for (var spec : buildSchema(entry)) {
            if (WEIGHT_PARAM.equals(spec.name())) {
                params.put(spec.name(), ValueBinding.EffectWeight.INSTANCE);
            } else {
                schema.add(spec);
                params.put(spec.name(), new ValueBinding.ParamRef(spec.name()));
            }
        }

        return new CompiledEffect(
                graphPath,
                DEFAULT_PRIORITY,
                true,
                List.copyOf(schema),
                List.of(new ResourceDesc(SizeSpec.screen(1f), TargetFormat.RGBA16F, 0, 0, "output")),
                List.of(new CompiledPass(graphPath, null, textures, params, 0)),
                0);
    }

    /** The schema defaults as an executor-ready params map (what an unblended invocation uses —
     *  e.g. the editor preview, which runs at weight 1 with no requests). */
    public Map<String, Object> defaultParams() {
        if (schema.isEmpty()) return Map.of();
        var params = new LinkedHashMap<String, Object>();
        for (var spec : schema) {
            if (spec.defaultValue() != null) params.put(spec.name(), spec.defaultValue());
        }
        return params;
    }

    /** The blendable parameter schema: every graph variable that compiled to a uniform field,
     *  lerpable when its GLSL type interpolates componentwise. */
    static List<ParamSpec> buildSchema(FullscreenGraphRuntime.Entry entry) {
        var graph = entry.getGraph();
        var compiled = entry.getCompiled();
        if (graph == null || compiled == null) return List.of();
        var schema = new ArrayList<ParamSpec>();
        for (var declaration : graph.graphModel.getGraphVariableModels()) {
            if (declaration == null) continue;
            var name = declaration.getName();
            var field = compiled.uniformFields().get(name);
            if (field == null) continue; // samplers / inlined constants aren't blendable params
            var defaultValue = declaration.tryGetDefaultValue(declaration.getDataType()).result().orElse(null);
            var lerpable = field.type() == GlslType.FLOAT || field.type() == GlslType.VEC2
                    || field.type() == GlslType.VEC3 || field.type() == GlslType.VEC4;
            schema.add(new ParamSpec(name, defaultValue, lerpable));
        }
        return List.copyOf(schema);
    }
}
