package com.lowdragmc.photon.client.gameobject.emitter.data;

import com.lowdragmc.lowdraglib2.configurator.IConfigurable;
import com.lowdragmc.lowdraglib2.configurator.annotation.ConfigList;
import com.lowdragmc.lowdraglib2.configurator.annotation.Configurable;
import com.lowdragmc.lowdraglib2.configurator.annotation.ConfigNumber;
import com.lowdragmc.lowdraglib2.configurator.ui.Configurator;
import com.lowdragmc.lowdraglib2.configurator.ui.ConfiguratorGroup;
import com.lowdragmc.lowdraglib2.configurator.ui.SearchComponentConfigurator;
import com.lowdragmc.lowdraglib2.gui.ui.utils.UIElementProvider;
import com.lowdragmc.lowdraglib2.syncdata.IPersistedSerializable;
import com.lowdragmc.lowdraglib2.syncdata.annotation.Persisted;
import com.lowdragmc.lowdraglib2.syncdata.annotation.ReadOnlyManaged;
import com.lowdragmc.photon.client.fx.FXHelper;
import com.lowdragmc.photon.client.gameobject.RuntimeValue;
import com.lowdragmc.photon.client.gameobject.emitter.IParticleEmitter;
import com.lowdragmc.photon.client.gameobject.emitter.data.number.Constant;
import com.lowdragmc.photon.client.gameobject.emitter.data.number.NumberFunction;
import com.lowdragmc.photon.client.gameobject.emitter.data.number.NumberFunctionConfig;
import com.lowdragmc.photon.client.gameobject.emitter.data.number.RandomConstant;
import com.lowdragmc.photon.client.gameobject.emitter.data.number.curve.Curve;
import com.lowdragmc.photon.client.gameobject.emitter.data.number.curve.CurveConfig;
import com.lowdragmc.photon.client.gameobject.emitter.data.number.curve.RandomCurve;
import com.lowdragmc.photon.client.gameobject.emitter.particle.ParticleEmitter;
import com.lowdragmc.photon.client.gameobject.particle.TileParticle;
import lombok.Getter;
import lombok.Setter;
import net.minecraft.nbt.IntTag;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.resources.Identifier;
import org.joml.Quaternionf;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * @author KilaBash
 * @date 2023/7/17
 * @implNote SubEmittersSetting
 */
@Setter
@Getter
public class SubEmittersSetting extends ToggleGroup {

    @Configurable(name = "SubEmittersSetting.emitters")
    @ConfigList(configuratorMethod = "buildEmitterConfigurator", addDefaultMethod = "addDefaultEmitter")
    @ReadOnlyManaged(serializeMethod = "emittersSerialize", deserializeMethod = "emittersDeserialize")
    protected List<Emitter> emitters = new ArrayList<>();

    public Runtime createRuntime() {
        return new Runtime(this);
    }

    public static class Runtime {
        private final SubEmittersSetting config;
        public final RuntimeValue<Boolean> enable;
        public final RuntimeValue<List<Emitter>> emitters; // slot only (list → no timeline binding)

        public Runtime(SubEmittersSetting config) {
            this.config = config;
            this.enable = new RuntimeValue<>(config::isEnable);
            this.emitters = new RuntimeValue<>(config::getEmitters);
        }

        public boolean isEnable() {
            return enable.get();
        }

        public void triggerEvent(TileParticle father, Event event) {
            for (Emitter candidate : emitters.get()) {
                if (candidate.event == event) {
                    candidate.spawnEmitter(father);
                }
            }
        }

        /**
         * Tick event with integer-tick-crossing semantics: fires when this step crossed a whole tick
         * and that tick matches the candidate's tickInterval. Robust under fractional dt (sub-stepped
         * timeline speed), where the particle's float age almost never lands exactly on an integer.
         */
        public void triggerTickEvent(TileParticle father, float dt) {
            var newTick = Mth.floor(father.getAge());
            if (newTick <= Mth.floor(father.getAge() - dt)) {
                return; // no whole tick crossed this step (dt <= 1 => at most one crossing)
            }
            for (Emitter candidate : emitters.get()) {
                if (candidate.event == Event.Tick && newTick % candidate.tickInterval == 0) {
                    candidate.spawnEmitter(father);
                }
            }
        }

        public void clear() {
            enable.clear();
            emitters.clear();
        }
    }

    private Configurator buildEmitterConfigurator(Supplier<Emitter> getter, Consumer<Emitter> setter) {
        var instance = getter.get();
        if (instance != null && instance.createDirectConfigurator() instanceof ConfiguratorGroup group) {
            group.setCollapse(false);
            group.lineContainer.setDisplay(false);
            return group;
        }
        return new Configurator();
    }

    private Emitter addDefaultEmitter() {
        return new Emitter();
    }

    private IntTag emittersSerialize(List<Emitter> bursts) {
        return IntTag.valueOf(bursts.size());
    }

    private List<Emitter> emittersDeserialize(IntTag tag) {
        var groups = new ArrayList<Emitter>();
        for (int i = 0; i < tag.intValue(); i++) {
            groups.add(addDefaultEmitter());
        }
        return groups;
    }

    public enum Event {
        Birth,
        Death,
        Collision,
        FirstCollision,
        Tick
    }

    @Setter
    @Getter
    public static class Emitter implements IConfigurable, IPersistedSerializable {
        @Nullable
        @Persisted
        protected Identifier fxLocation = null;
        @Configurable(name = "Emitter.event", tips = "photon.emitter.config.sub_emitters.emitter.event")
        protected Event event = Event.Birth;
        @Configurable(name = "Emitter.emitProbability", tips = "photon.emitter.config.sub_emitters.emitter.emit_probability")
        @NumberFunctionConfig(types = {Constant.class, RandomConstant.class, Curve.class, RandomCurve.class}, min = 0, max = 1, curveConfig = @CurveConfig(bound = {0, 1}, xAxis = "probability", yAxis = "lifetime"))
        protected NumberFunction emitProbability = NumberFunction.constant(0);
        @Configurable(name = "Emitter.tickInterval", tips = "photon.emitter.config.sub_emitters.emitter.tick_interval")
        @ConfigNumber(range = {1, Integer.MAX_VALUE})
        protected int tickInterval = 1;
        @Configurable(name = "Emitter.inheritColor", tips = "photon.emitter.config.sub_emitters.emitter.inherit_color")
        protected boolean inheritColor = false;
        @Configurable(name = "Emitter.inheritSize", tips = "photon.emitter.config.sub_emitters.emitter.inherit_size")
        protected boolean inheritSize = false;
        @Configurable(name = "Emitter.inheritRotation", tips = "photon.emitter.config.sub_emitters.emitter.inherit_rotation")
        protected boolean inheritRotation = false;
        @Configurable(name = "Emitter.inheritLifetime", tips = "photon.emitter.config.sub_emitters.emitter.inherit_lifetime")
        protected boolean inheritLifetime = false;
        @Configurable(name = "Emitter.inheritDuration", tips = "photon.emitter.config.sub_emitters.emitter.inherit_duration")
        protected boolean inheritDuration = false;

        public void spawnEmitter(TileParticle father) {
            if (fxLocation == null) {
                return;
            }
            // probability roll stays here: the particle's RandomSource is confined to its update thread
            if (father.getRandomSource().nextFloat() >= emitProbability.get(father.getT(0),
                    () -> father.getMemRandom("sub_emitter_probability")).floatValue()) {
                return;
            }
            // FXHelper.getFX + FXRuntime.emit (particle engine) are not thread-safe: particle updates
            // may run on parallelStream workers, so defer the spawn to the game thread — the owning
            // emitter drains it at the end of the same tick (deferred in serial mode too, so ordering
            // is mode-independent; a dead particle's fields stay valid until next tick's removal).
            if (father.getEmitter() instanceof ParticleEmitter particleEmitter) {
                particleEmitter.scheduleSubEmitterSpawn(() -> doSpawn(father));
            } else {
                doSpawn(father); // non-ParticleEmitter owners never parallel-update TileParticles
            }
        }

        private void doSpawn(TileParticle father) {
            var fx = FXHelper.getFX(fxLocation);
            if (fx == null) return;
            var runtime = fx.createRuntime();
            runtime.root.updatePos(father.getWorldPos());
            for (var value : runtime.objects.values()) {
                if (value instanceof IParticleEmitter particleEmitter) {
                    if (inheritLifetime) {
                        particleEmitter.setAge((int) father.getAge());
                    }
                    if (inheritDuration) {
                        particleEmitter.self().setLifetime(father.getLifetime());
                    }
                    if (inheritColor) {
                        particleEmitter.setRGBAColor(father.getRealColor(0));
                    }
                    if (inheritSize) {
                        particleEmitter.transform().scale(father.getRealSize(0));
                    }
                    if (inheritRotation) {
                        var xyz = father.getRealRotation(0);
                        particleEmitter.transform().rotation(new Quaternionf().rotationXYZ(xyz.x, xyz.y, xyz.z));
                    }
                }
            }
            runtime.emit(father.getEmitter().getEffectExecutor());
        }

        @Override
        public void buildConfigurator(ConfiguratorGroup father) {
            // The search runs per keystroke, so it gets a plain list to scan: FXHelper owns the caching
            // (and drops it on resource reload), and the ids are turned into strings once here rather
            // than once per search. The leading "" is the entry that clears the selection.
            var candidates = new ArrayList<String>();
            candidates.add("");
            FXHelper.listAllFX().forEach(fx -> candidates.add(fx.toString()));

            father.addConfigurators(new SearchComponentConfigurator<>("fx",
                    () -> fxLocation == null ? "" : fxLocation.toString(),
                    v -> fxLocation = (v == null || v.isEmpty()) ? null : Identifier.parse(v),
                    "", true,
                    (word, handler) -> {
                        if (Thread.currentThread().isInterrupted()) return;
                        var search = word.toLowerCase(Locale.ROOT);
                        for (var candidate : candidates) {
                            if (Thread.currentThread().isInterrupted()) return;
                            if (candidate.toLowerCase(Locale.ROOT).contains(search)) {
                                handler.accept(candidate);
                            }
                        }
                    },
                    s -> s,
                    UIElementProvider.text(s -> Component.literal(s == null || s.isEmpty() ? "---" : s)))
                    .setTips("photon.emitter.config.sub_emitters.emitter.name"));
            IConfigurable.super.buildConfigurator(father);
        }
    }
}
