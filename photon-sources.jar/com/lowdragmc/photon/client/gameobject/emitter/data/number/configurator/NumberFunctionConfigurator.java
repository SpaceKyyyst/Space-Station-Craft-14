package com.lowdragmc.photon.client.gameobject.emitter.data.number.configurator;

import com.lowdragmc.lowdraglib2.configurator.ui.ValueConfigurator;
import com.lowdragmc.lowdraglib2.gui.texture.Icons;
import com.lowdragmc.lowdraglib2.gui.texture.IGuiTexture;
import com.lowdragmc.lowdraglib2.gui.ui.UIElement;
import com.lowdragmc.lowdraglib2.gui.ui.elements.Button;
import com.lowdragmc.lowdraglib2.gui.ui.elements.Menu;
import com.lowdragmc.lowdraglib2.gui.util.TreeBuilder;
import com.lowdragmc.photon.PhotonRegistries;
import com.lowdragmc.photon.client.gameobject.emitter.data.number.NumberFunction;
import com.lowdragmc.photon.client.gameobject.emitter.data.number.NumberFunctionConfig;
import dev.vfyjxf.taffy.style.FlexDirection;
import dev.vfyjxf.taffy.style.FlexWrap;
import lombok.Getter;
import com.mojang.logging.annotations.MethodsReturnNonnullByDefault;

import javax.annotation.Nullable;
import javax.annotation.ParametersAreNonnullByDefault;
import java.util.Arrays;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.stream.Collectors;


/**
 * @author KilaBash
 * @date 2022/12/1
 * @implNote NumberFunctionConfigurator
 */
@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
public class NumberFunctionConfigurator extends ValueConfigurator<NumberFunction> {
    public final Button numberFunctionButton = new Button();
    @Getter
    private NumberFunctionConfig config;

    public NumberFunctionConfigurator(String name, Supplier<NumberFunction> supplier, Consumer<NumberFunction> onUpdate, boolean forceUpdate, NumberFunctionConfig config) {
        super(name, supplier, onUpdate, defaultFunction(config), forceUpdate);
        this.config = config;
        if (value == null) {
            value = defaultValue;
        }
        value.createConfigurator(this);
        this.lineContainer.addChildAt(numberFunctionButton, 2);
        if (config.types().length <= 1) {
            numberFunctionButton.setDisplay(false);
        } else {
            numberFunctionButton.noText().setOnClick(e -> {
                var menu = TreeBuilder.Menu.start();
                var types = Arrays.stream(config.types()).collect(Collectors.toSet());
                for (var holder : PhotonRegistries.NUMBER_FUNCTIONS) {
                    var clazz = holder.clazz();
                    if (types.contains(clazz)) {
                        menu.leaf(clazz == value.getClass() ? Icons.CHECK_SPRITE : IGuiTexture.EMPTY, holder.annotation().name(), () -> {
                            var newValue = holder.value().get();
                            newValue.loadConfig(config);
                            updateValue(newValue);
                            clearInlineContainer();
                            value.createConfigurator(this);
                        });
                    }
                }
                var mui = getModularUI();
                if (mui != null) {
                    mui.ui.rootElement.addChild(new Menu<>(menu.build(), TreeBuilder.Menu::uiProvider)
                            .setHoverTextureProvider(TreeBuilder.Menu::hoverTextureProvider)
                            .setOnNodeClicked(TreeBuilder.Menu::handle)
                            .layout(layout -> {
                                layout.left( numberFunctionButton.getPositionX() +
                                        numberFunctionButton.getSizeWidth() - 120 + - mui.ui.rootElement.getPositionX());
                                layout.top( numberFunctionButton.getPositionY() +
                                        numberFunctionButton.getSizeHeight() - mui.ui.rootElement.getContentY());
                            }));
                }
            }).layout(layout -> {
                layout.setAspectRatio(1);
            }).addChild(new UIElement().layout(layout -> {
                layout.widthPercent(100);
                layout.heightPercent(100);
            }).style(style -> style.backgroundTexture(Icons.DOWN_ARROW_NO_BAR)));
        }
        setCopiable(value -> value.copy());
        // Only the function types this field actually offers. A function outside config.types() can be
        // stored but never switched back to from the dropdown, and the sets are not interchangeable
        // (a scalar function in a colour slot, or an LDR colour in an HDR one) — so refuse it outright.
        var allowedTypes = Arrays.stream(config.types()).collect(Collectors.toSet());
        setPastable(allowedTypes::contains, pasted -> {
            if (pasted instanceof NumberFunction function) {
                onPaste(function);
            }
        });
        setCanDropPredicate(object -> object != null && allowedTypes.contains(object.getClass()));
    }

    /**
     * A fresh instance of the field's first offered function type, configured from {@code config}. Used
     * as the fallback when the supplier has no value — it must be one of the offered types, otherwise a
     * colour field would fall back to a numeric spinner.
     */
    private static NumberFunction defaultFunction(NumberFunctionConfig config) {
        var types = config.types();
        if (types.length > 0) {
            for (var holder : PhotonRegistries.NUMBER_FUNCTIONS) {
                if (holder.clazz() == types[0]) {
                    var function = holder.value().get();
                    function.loadConfig(config);
                    return function;
                }
            }
        }
        return NumberFunction.constant(config.defaultValue());
    }

    @Override
    protected void onValueUpdatePassively(@Nullable NumberFunction newValue) {
        if (newValue == null) newValue = defaultValue;
        if (newValue == value || NumberFunction.isEqual(newValue, value)) return;
        super.onValueUpdatePassively(newValue);
        clearInlineContainer();
        newValue.createConfigurator(this);
    }

    private void clearInlineContainer() {
        inlineContainer.clearAllChildren();
        inlineContainer.layout(layout -> {
            layout.gapAll(0);
            layout.marginLeft(0);
            layout.flexDirection(FlexDirection.COLUMN);
            layout.wrap(FlexWrap.NO_WRAP);
        });
    }

    @Override
    protected void updateValueActively(NumberFunction newValue) {
        var notifyChange = value != newValue;
        value = newValue;
        if (onUpdate != null) {
            onUpdate.accept(value);
        }
        if (notifyChange) {
            notifyChanges();
        }
    }

    public void updateValue(NumberFunction value) {
        updateValueActively(value);
    }

}
