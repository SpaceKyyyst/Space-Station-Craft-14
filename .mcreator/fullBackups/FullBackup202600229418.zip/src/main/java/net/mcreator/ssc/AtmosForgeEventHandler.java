
package net.mcreator.ssc;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.LevelAccessor;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.LevelTickEvent; // ИСПРАВЛЕНО под NeoForge 26.x
import net.neoforged.neoforge.event.level.BlockEvent;

@EventBusSubscriber(modid = "ssc_14")
public class AtmosForgeEventHandler {

    @SubscribeEvent
    public static void onLevelTick(LevelTickEvent event) {
        // ИСПРАВЛЕНО: В NeoForge 26.x тики плоские, проверка идет через уровень и сторону
        if (event.getLevel() instanceof ServerLevel serverLevel) {
            if (!serverLevel.isClientSide()) { // ИСПРАВЛЕНО: Вызов метода со скобками
                AtmosphereManager.get(serverLevel).tick();
            }
        }
    }

    @SubscribeEvent
    public static void onBlockPlace(BlockEvent.EntityPlaceEvent event) {
        handleBlockChange(event.getLevel(), event.getPos());
    }

    @SubscribeEvent
    public static void onBlockBreak(BlockEvent.BreakEvent event) {
        if (event.getPos() != null) {
            handleBlockChange(event.getLevel(), event.getPos());
        }
    }

    private static void handleBlockChange(LevelAccessor level, BlockPos pos) {
        if (level instanceof ServerLevel serverLevel && pos != null) {
            if (!serverLevel.isClientSide()) { // ИСПРАВЛЕНО: Вызов метода со скобками
                AtmosphereManager.get(serverLevel).onBlockChanged(pos);
            }
        }
    }
}
