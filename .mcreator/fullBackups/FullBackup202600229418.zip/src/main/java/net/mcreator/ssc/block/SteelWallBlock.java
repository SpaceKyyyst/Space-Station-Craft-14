
package net.mcreator.ssc.block;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.entity.player.Player;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

import net.mcreator.ssc.procedures.Wall_Explosion_BreakdownProcedure;
import net.mcreator.ssc.procedures.SteelWall_DestroyProcedure;

public class SteelWallBlock extends Block {
	public SteelWallBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.NETHERITE_BLOCK).strength(30f, 12f));
	}

	@Override
	public boolean onDestroyedByPlayer(BlockState blockstate, Level world, BlockPos pos, Player entity, boolean willHarvest, FluidState fluid) {
		boolean retval = super.onDestroyedByPlayer(blockstate, world, pos, entity, willHarvest, fluid);
		SteelWall_DestroyProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ(), entity);
		return retval;
	}

	@Override
	public void wasExploded(ServerLevel world, BlockPos pos, Explosion e) {
		// Мы НЕ вызываем super.wasExploded, чтобы ванильный взрыв сразу не удалял блок.
		// Вместо этого передаем объект взрыва 'e' в нашу процедуру.
		Wall_Explosion_BreakdownProcedure.execute(world, pos.getX(), pos.getY(), pos.getZ(), e);
	}
}
