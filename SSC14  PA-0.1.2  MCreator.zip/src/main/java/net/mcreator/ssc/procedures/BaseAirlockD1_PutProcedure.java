package net.mcreator.ssc.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.storage.TagValueInput;
import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Mob;
import net.minecraft.util.ProblemReporter;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import net.mcreator.ssc.init.Ssc14ModBlocks;
import net.mcreator.ssc.Ssc14Mod;

public class BaseAirlockD1_PutProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, BlockState blockstate) {
		if (!((world.getBlockState(BlockPos.containing(x, y + 1, z))).getBlock() == Ssc14ModBlocks.BASE_AIRLOCK_U_1.get())) {
			if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Ssc14ModBlocks.BASE_AIRLOCK_D_1.get()) {
				world.setBlock(BlockPos.containing(x, y + 1, z), Ssc14ModBlocks.BASE_AIRLOCK_U_1.get().defaultBlockState(), 3);
				{
					Direction _dir = (getDirectionFromBlockState(blockstate));
					BlockPos _pos = BlockPos.containing(x, y + 1, z);
					BlockState _bs = world.getBlockState(_pos);
					if (_bs.getBlock().getStateDefinition().getProperty("facing") instanceof EnumProperty _dp && _dp.getPossibleValues().contains(_dir)) {
						world.setBlock(_pos, _bs.setValue(_dp, _dir), 3);
					} else if (_bs.getBlock().getStateDefinition().getProperty("axis") instanceof EnumProperty _ap && _ap.getPossibleValues().contains(_dir.getAxis())) {
						world.setBlock(_pos, _bs.setValue(_ap, _dir.getAxis()), 3);
					}
				}
			}
		} else if (!((world.getBlockState(BlockPos.containing(x, y + 1, z))).getBlock() == Ssc14ModBlocks.BASE_AIRLOCK_U_2.get())) {
			if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Ssc14ModBlocks.BASE_AIRLOCK_D_2.get()) {
				world.setBlock(BlockPos.containing(x, y + 1, z), Ssc14ModBlocks.BASE_AIRLOCK_U_2.get().defaultBlockState(), 3);
				{
					Direction _dir = (getDirectionFromBlockState(blockstate));
					BlockPos _pos = BlockPos.containing(x, y + 1, z);
					BlockState _bs = world.getBlockState(_pos);
					if (_bs.getBlock().getStateDefinition().getProperty("facing") instanceof EnumProperty _dp && _dp.getPossibleValues().contains(_dir)) {
						world.setBlock(_pos, _bs.setValue(_dp, _dir), 3);
					} else if (_bs.getBlock().getStateDefinition().getProperty("axis") instanceof EnumProperty _ap && _ap.getPossibleValues().contains(_dir.getAxis())) {
						world.setBlock(_pos, _bs.setValue(_ap, _dir.getAxis()), 3);
					}
				}
			}
		} else if (!((world.getBlockState(BlockPos.containing(x, y + 1, z))).getBlock() == Ssc14ModBlocks.BASE_AIRLOCK_U_3.get())) {
			if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Ssc14ModBlocks.BASE_AIRLOCK_D_3.get()) {
				world.setBlock(BlockPos.containing(x, y + 1, z), Ssc14ModBlocks.BASE_AIRLOCK_U_3.get().defaultBlockState(), 3);
				{
					Direction _dir = (getDirectionFromBlockState(blockstate));
					BlockPos _pos = BlockPos.containing(x, y + 1, z);
					BlockState _bs = world.getBlockState(_pos);
					if (_bs.getBlock().getStateDefinition().getProperty("facing") instanceof EnumProperty _dp && _dp.getPossibleValues().contains(_dir)) {
						world.setBlock(_pos, _bs.setValue(_dp, _dir), 3);
					} else if (_bs.getBlock().getStateDefinition().getProperty("axis") instanceof EnumProperty _ap && _ap.getPossibleValues().contains(_dir.getAxis())) {
						world.setBlock(_pos, _bs.setValue(_ap, _dir.getAxis()), 3);
					}
				}
			}
		} else if (!((world.getBlockState(BlockPos.containing(x, y + 1, z))).getBlock() == Ssc14ModBlocks.BASE_AIRLOCK_U_4.get())) {
			if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Ssc14ModBlocks.BASE_AIRLOCK_D_4.get()) {
				world.setBlock(BlockPos.containing(x, y + 1, z), Ssc14ModBlocks.BASE_AIRLOCK_U_4.get().defaultBlockState(), 3);
				{
					Direction _dir = (getDirectionFromBlockState(blockstate));
					BlockPos _pos = BlockPos.containing(x, y + 1, z);
					BlockState _bs = world.getBlockState(_pos);
					if (_bs.getBlock().getStateDefinition().getProperty("facing") instanceof EnumProperty _dp && _dp.getPossibleValues().contains(_dir)) {
						world.setBlock(_pos, _bs.setValue(_dp, _dir), 3);
					} else if (_bs.getBlock().getStateDefinition().getProperty("axis") instanceof EnumProperty _ap && _ap.getPossibleValues().contains(_dir.getAxis())) {
						world.setBlock(_pos, _bs.setValue(_ap, _dir.getAxis()), 3);
					}
				}
			}
		} else if (!((world.getBlockState(BlockPos.containing(x, y + 1, z))).getBlock() == Ssc14ModBlocks.BASE_AIRLOCK_U_5.get())) {
			if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Ssc14ModBlocks.BASE_AIRLOCK_D_5.get()) {
				world.setBlock(BlockPos.containing(x, y + 1, z), Ssc14ModBlocks.BASE_AIRLOCK_U_5.get().defaultBlockState(), 3);
				{
					Direction _dir = (getDirectionFromBlockState(blockstate));
					BlockPos _pos = BlockPos.containing(x, y + 1, z);
					BlockState _bs = world.getBlockState(_pos);
					if (_bs.getBlock().getStateDefinition().getProperty("facing") instanceof EnumProperty _dp && _dp.getPossibleValues().contains(_dir)) {
						world.setBlock(_pos, _bs.setValue(_dp, _dir), 3);
					} else if (_bs.getBlock().getStateDefinition().getProperty("axis") instanceof EnumProperty _ap && _ap.getPossibleValues().contains(_dir.getAxis())) {
						world.setBlock(_pos, _bs.setValue(_ap, _dir.getAxis()), 3);
					}
				}
			}
		} else if (!((world.getBlockState(BlockPos.containing(x, y + 1, z))).getBlock() == Ssc14ModBlocks.BASE_AIRLOCK_U_6.get())) {
			if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Ssc14ModBlocks.BASE_AIRLOCK_D_6.get()) {
				world.setBlock(BlockPos.containing(x, y + 1, z), Ssc14ModBlocks.BASE_AIRLOCK_U_6.get().defaultBlockState(), 3);
				{
					Direction _dir = (getDirectionFromBlockState(blockstate));
					BlockPos _pos = BlockPos.containing(x, y + 1, z);
					BlockState _bs = world.getBlockState(_pos);
					if (_bs.getBlock().getStateDefinition().getProperty("facing") instanceof EnumProperty _dp && _dp.getPossibleValues().contains(_dir)) {
						world.setBlock(_pos, _bs.setValue(_dp, _dir), 3);
					} else if (_bs.getBlock().getStateDefinition().getProperty("axis") instanceof EnumProperty _ap && _ap.getPossibleValues().contains(_dir.getAxis())) {
						world.setBlock(_pos, _bs.setValue(_ap, _dir.getAxis()), 3);
					}
				}
			}
		}
		if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Ssc14ModBlocks.BASE_AIRLOCK_D_6.get()) {
			Ssc14Mod.queueServerWork(20, () -> {
				if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Ssc14ModBlocks.BASE_AIRLOCK_D_6.get()) {
					Ssc14Mod.queueServerWork(20, () -> {
						if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Ssc14ModBlocks.BASE_AIRLOCK_D_6.get()) {
							Ssc14Mod.queueServerWork(20, () -> {
								if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Ssc14ModBlocks.BASE_AIRLOCK_D_6.get()) {
									Ssc14Mod.queueServerWork(20, () -> {
										if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Ssc14ModBlocks.BASE_AIRLOCK_D_6.get()) {
											Ssc14Mod.queueServerWork(20, () -> {
												if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Ssc14ModBlocks.BASE_AIRLOCK_D_6.get()
														&& !(!world.getEntitiesOfClass(Player.class, new AABB(Vec3.ZERO, Vec3.ZERO).move(new Vec3((x + 0.5), (y + 1), (z + 0.5))).inflate(0.4 / 2d), e -> true).isEmpty())
														&& !(!world.getEntitiesOfClass(Mob.class, new AABB(Vec3.ZERO, Vec3.ZERO).move(new Vec3((x + 0.5), (y + 1), (z + 0.5))).inflate(0.4 / 2d), e -> true).isEmpty())) {
													if (world instanceof Level _level) {
														if (!_level.isClientSide()) {
															_level.playSound(null, BlockPos.containing(x, y, z), BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("ssc_14:airlock_close")), SoundSource.NEUTRAL, 1, 1);
														} else {
															_level.playLocalSound(x, y, z, BuiltInRegistries.SOUND_EVENT.getValue(ResourceLocation.parse("ssc_14:airlock_close")), SoundSource.NEUTRAL, 1, 1, false);
														}
													}
													Ssc14Mod.queueServerWork(2, () -> {
														if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Ssc14ModBlocks.BASE_AIRLOCK_D_6.get()) {
															{
																BlockPos _bp = BlockPos.containing(x, y, z);
																BlockState _bs = Ssc14ModBlocks.BASE_AIRLOCK_D_5.get().defaultBlockState();
																BlockState _bso = world.getBlockState(_bp);
																for (Property<?> _propertyOld : _bso.getProperties()) {
																	Property _propertyNew = _bs.getBlock().getStateDefinition().getProperty(_propertyOld.getName());
																	if (_propertyNew != null && _bs.getValue(_propertyNew) != null)
																		try {
																			_bs = _bs.setValue(_propertyNew, _bso.getValue(_propertyOld));
																		} catch (Exception e) {
																		}
																}
																BlockEntity _be = world.getBlockEntity(_bp);
																CompoundTag _bnbt = null;
																if (_be != null) {
																	_bnbt = _be.saveWithFullMetadata(world.registryAccess());
																	_be.setRemoved();
																}
																world.setBlock(_bp, _bs, 3);
																if (_bnbt != null) {
																	_be = world.getBlockEntity(_bp);
																	if (_be != null) {
																		try {
																			_be.loadWithComponents(TagValueInput.create(ProblemReporter.DISCARDING, world.registryAccess(), _bnbt));
																		} catch (Exception ignored) {
																		}
																	}
																}
															}
															Ssc14Mod.queueServerWork(2, () -> {
																if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Ssc14ModBlocks.BASE_AIRLOCK_D_5.get()) {
																	{
																		BlockPos _bp = BlockPos.containing(x, y, z);
																		BlockState _bs = Ssc14ModBlocks.BASE_AIRLOCK_D_4.get().defaultBlockState();
																		BlockState _bso = world.getBlockState(_bp);
																		for (Property<?> _propertyOld : _bso.getProperties()) {
																			Property _propertyNew = _bs.getBlock().getStateDefinition().getProperty(_propertyOld.getName());
																			if (_propertyNew != null && _bs.getValue(_propertyNew) != null)
																				try {
																					_bs = _bs.setValue(_propertyNew, _bso.getValue(_propertyOld));
																				} catch (Exception e) {
																				}
																		}
																		BlockEntity _be = world.getBlockEntity(_bp);
																		CompoundTag _bnbt = null;
																		if (_be != null) {
																			_bnbt = _be.saveWithFullMetadata(world.registryAccess());
																			_be.setRemoved();
																		}
																		world.setBlock(_bp, _bs, 3);
																		if (_bnbt != null) {
																			_be = world.getBlockEntity(_bp);
																			if (_be != null) {
																				try {
																					_be.loadWithComponents(TagValueInput.create(ProblemReporter.DISCARDING, world.registryAccess(), _bnbt));
																				} catch (Exception ignored) {
																				}
																			}
																		}
																	}
																	Ssc14Mod.queueServerWork(2, () -> {
																		if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Ssc14ModBlocks.BASE_AIRLOCK_D_4.get()) {
																			{
																				BlockPos _bp = BlockPos.containing(x, y, z);
																				BlockState _bs = Ssc14ModBlocks.BASE_AIRLOCK_D_3.get().defaultBlockState();
																				BlockState _bso = world.getBlockState(_bp);
																				for (Property<?> _propertyOld : _bso.getProperties()) {
																					Property _propertyNew = _bs.getBlock().getStateDefinition().getProperty(_propertyOld.getName());
																					if (_propertyNew != null && _bs.getValue(_propertyNew) != null)
																						try {
																							_bs = _bs.setValue(_propertyNew, _bso.getValue(_propertyOld));
																						} catch (Exception e) {
																						}
																				}
																				BlockEntity _be = world.getBlockEntity(_bp);
																				CompoundTag _bnbt = null;
																				if (_be != null) {
																					_bnbt = _be.saveWithFullMetadata(world.registryAccess());
																					_be.setRemoved();
																				}
																				world.setBlock(_bp, _bs, 3);
																				if (_bnbt != null) {
																					_be = world.getBlockEntity(_bp);
																					if (_be != null) {
																						try {
																							_be.loadWithComponents(TagValueInput.create(ProblemReporter.DISCARDING, world.registryAccess(), _bnbt));
																						} catch (Exception ignored) {
																						}
																					}
																				}
																			}
																			Ssc14Mod.queueServerWork(2, () -> {
																				if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Ssc14ModBlocks.BASE_AIRLOCK_D_3.get()) {
																					{
																						BlockPos _bp = BlockPos.containing(x, y, z);
																						BlockState _bs = Ssc14ModBlocks.BASE_AIRLOCK_D_2.get().defaultBlockState();
																						BlockState _bso = world.getBlockState(_bp);
																						for (Property<?> _propertyOld : _bso.getProperties()) {
																							Property _propertyNew = _bs.getBlock().getStateDefinition().getProperty(_propertyOld.getName());
																							if (_propertyNew != null && _bs.getValue(_propertyNew) != null)
																								try {
																									_bs = _bs.setValue(_propertyNew, _bso.getValue(_propertyOld));
																								} catch (Exception e) {
																								}
																						}
																						BlockEntity _be = world.getBlockEntity(_bp);
																						CompoundTag _bnbt = null;
																						if (_be != null) {
																							_bnbt = _be.saveWithFullMetadata(world.registryAccess());
																							_be.setRemoved();
																						}
																						world.setBlock(_bp, _bs, 3);
																						if (_bnbt != null) {
																							_be = world.getBlockEntity(_bp);
																							if (_be != null) {
																								try {
																									_be.loadWithComponents(TagValueInput.create(ProblemReporter.DISCARDING, world.registryAccess(), _bnbt));
																								} catch (Exception ignored) {
																								}
																							}
																						}
																					}
																					Ssc14Mod.queueServerWork(2, () -> {
																						if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Ssc14ModBlocks.BASE_AIRLOCK_D_2.get()) {
																							{
																								BlockPos _bp = BlockPos.containing(x, y, z);
																								BlockState _bs = Ssc14ModBlocks.BASE_AIRLOCK_D_1.get().defaultBlockState();
																								BlockState _bso = world.getBlockState(_bp);
																								for (Property<?> _propertyOld : _bso.getProperties()) {
																									Property _propertyNew = _bs.getBlock().getStateDefinition().getProperty(_propertyOld.getName());
																									if (_propertyNew != null && _bs.getValue(_propertyNew) != null)
																										try {
																											_bs = _bs.setValue(_propertyNew, _bso.getValue(_propertyOld));
																										} catch (Exception e) {
																										}
																								}
																								BlockEntity _be = world.getBlockEntity(_bp);
																								CompoundTag _bnbt = null;
																								if (_be != null) {
																									_bnbt = _be.saveWithFullMetadata(world.registryAccess());
																									_be.setRemoved();
																								}
																								world.setBlock(_bp, _bs, 3);
																								if (_bnbt != null) {
																									_be = world.getBlockEntity(_bp);
																									if (_be != null) {
																										try {
																											_be.loadWithComponents(TagValueInput.create(ProblemReporter.DISCARDING, world.registryAccess(), _bnbt));
																										} catch (Exception ignored) {
																										}
																									}
																								}
																							}
																						}
																					});
																				}
																			});
																		}
																	});
																}
															});
														}
													});
												} else {
													if (world instanceof Level _level)
														_level.updateNeighborsAt(BlockPos.containing(x, y, z), _level.getBlockState(BlockPos.containing(x, y, z)).getBlock());
													Ssc14Mod.queueServerWork(1, () -> {
														if (world instanceof Level _level)
															_level.updateNeighborsAt(BlockPos.containing(x, y, z), _level.getBlockState(BlockPos.containing(x, y, z)).getBlock());
													});
												}
											});
										}
									});
								}
							});
						}
					});
				}
			});
		}
	}

	private static Direction getDirectionFromBlockState(BlockState blockState) {
		if (blockState.getBlock().getStateDefinition().getProperty("facing") instanceof EnumProperty ep && ep.getValueClass() == Direction.class)
			return (Direction) blockState.getValue(ep);
		if (blockState.getBlock().getStateDefinition().getProperty("axis") instanceof EnumProperty ep && ep.getValueClass() == Direction.Axis.class)
			return Direction.fromAxisAndDirection((Direction.Axis) blockState.getValue(ep), Direction.AxisDirection.POSITIVE);
		return Direction.NORTH;
	}
}