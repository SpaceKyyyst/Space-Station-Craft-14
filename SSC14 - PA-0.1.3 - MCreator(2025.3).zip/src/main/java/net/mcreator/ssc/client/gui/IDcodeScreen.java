package net.mcreator.ssc.client.gui;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.Checkbox;
import net.minecraft.client.gui.GuiGraphics;

import net.mcreator.ssc.world.inventory.IDcodeMenu;
import net.mcreator.ssc.procedures.*;
import net.mcreator.ssc.init.Ssc14ModScreens;

import java.security.Security;

import java.lang.ref.Cleaner;

import com.mojang.brigadier.Command;

import com.google.common.util.concurrent.Service;

public class IDcodeScreen extends AbstractContainerScreen<IDcodeMenu> implements Ssc14ModScreens.ScreenAccessor {
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	private boolean menuStateUpdateActive = false;
	private Checkbox gun_room;
	private Checkbox HoS;
	private Checkbox Brig;
	private Checkbox Security;
	private Checkbox Detective;
	private Checkbox Blue_Sh;
	private Checkbox CE;
	private Checkbox CMO;
	private Checkbox RD;
	private Checkbox PNT;
	private Checkbox HoP;
	private Checkbox Atmos;
	private Checkbox Ingeneer;
	private Checkbox Qm;
	private Checkbox Utilizat;
	private Checkbox Supply_Deportament;
	private Checkbox Technical;
	private Checkbox Chemistry;
	private Checkbox Medical;
	private Checkbox Scientist;
	private Checkbox Out;
	private Checkbox Crio;
	private Checkbox Capitan;
	private Checkbox Service;
	private Checkbox Kitchen;
	private Checkbox Gidroponic;
	private Checkbox Bar;
	private Checkbox Teatre;
	private Checkbox Cleaner;
	private Checkbox Command;
	private Checkbox Uridic;
	private Checkbox Church;

	public IDcodeScreen(IDcodeMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 416;
		this.imageHeight = 235;
	}

	@Override
	public void updateMenuState(int elementType, String name, Object elementState) {
		menuStateUpdateActive = true;
		if (elementType == 1 && elementState instanceof Boolean logicState) {
			if (name.equals("gun_room")) {
				if (gun_room.selected() != logicState)
					gun_room.onPress();
			} else if (name.equals("HoS")) {
				if (HoS.selected() != logicState)
					HoS.onPress();
			} else if (name.equals("Brig")) {
				if (Brig.selected() != logicState)
					Brig.onPress();
			} else if (name.equals("Security")) {
				if (Security.selected() != logicState)
					Security.onPress();
			} else if (name.equals("Detective")) {
				if (Detective.selected() != logicState)
					Detective.onPress();
			} else if (name.equals("Blue_Sh")) {
				if (Blue_Sh.selected() != logicState)
					Blue_Sh.onPress();
			} else if (name.equals("CE")) {
				if (CE.selected() != logicState)
					CE.onPress();
			} else if (name.equals("CMO")) {
				if (CMO.selected() != logicState)
					CMO.onPress();
			} else if (name.equals("RD")) {
				if (RD.selected() != logicState)
					RD.onPress();
			} else if (name.equals("PNT")) {
				if (PNT.selected() != logicState)
					PNT.onPress();
			} else if (name.equals("HoP")) {
				if (HoP.selected() != logicState)
					HoP.onPress();
			} else if (name.equals("Atmos")) {
				if (Atmos.selected() != logicState)
					Atmos.onPress();
			} else if (name.equals("Ingeneer")) {
				if (Ingeneer.selected() != logicState)
					Ingeneer.onPress();
			} else if (name.equals("Qm")) {
				if (Qm.selected() != logicState)
					Qm.onPress();
			} else if (name.equals("Utilizat")) {
				if (Utilizat.selected() != logicState)
					Utilizat.onPress();
			} else if (name.equals("Supply_Deportament")) {
				if (Supply_Deportament.selected() != logicState)
					Supply_Deportament.onPress();
			} else if (name.equals("Technical")) {
				if (Technical.selected() != logicState)
					Technical.onPress();
			} else if (name.equals("Chemistry")) {
				if (Chemistry.selected() != logicState)
					Chemistry.onPress();
			} else if (name.equals("Medical")) {
				if (Medical.selected() != logicState)
					Medical.onPress();
			} else if (name.equals("Scientist")) {
				if (Scientist.selected() != logicState)
					Scientist.onPress();
			} else if (name.equals("Out")) {
				if (Out.selected() != logicState)
					Out.onPress();
			} else if (name.equals("Crio")) {
				if (Crio.selected() != logicState)
					Crio.onPress();
			} else if (name.equals("Capitan")) {
				if (Capitan.selected() != logicState)
					Capitan.onPress();
			} else if (name.equals("Service")) {
				if (Service.selected() != logicState)
					Service.onPress();
			} else if (name.equals("Kitchen")) {
				if (Kitchen.selected() != logicState)
					Kitchen.onPress();
			} else if (name.equals("Gidroponic")) {
				if (Gidroponic.selected() != logicState)
					Gidroponic.onPress();
			} else if (name.equals("Bar")) {
				if (Bar.selected() != logicState)
					Bar.onPress();
			} else if (name.equals("Teatre")) {
				if (Teatre.selected() != logicState)
					Teatre.onPress();
			} else if (name.equals("Cleaner")) {
				if (Cleaner.selected() != logicState)
					Cleaner.onPress();
			} else if (name.equals("Command")) {
				if (Command.selected() != logicState)
					Command.onPress();
			} else if (name.equals("Uridic")) {
				if (Uridic.selected() != logicState)
					Uridic.onPress();
			} else if (name.equals("Church")) {
				if (Church.selected() != logicState)
					Church.onPress();
			}
		}
		menuStateUpdateActive = false;
	}

	private static final ResourceLocation texture = ResourceLocation.parse("ssc_14:textures/screens/i_dcode.png");

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int mouseX, int mouseY) {
		guiGraphics.blit(RenderPipelines.GUI_TEXTURED, texture, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/i_dcode___copy.png"), this.leftPos + 0, this.topPos + 0, 0, 0, 416, 235, 416, 235);
		if (IDcmdecor1Procedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/id_code_menu_decor1.png"), this.leftPos + 49, this.topPos + 180, 0, 0, 17, 3, 17, 3);
		}
		if (IDcmdecor2Procedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/id_code_menu_decor2.png"), this.leftPos + 52, this.topPos + 184, 0, 0, 9, 10, 9, 10);
		}
		if (IDcmdecor3Procedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/id_code_menu_decor3.png"), this.leftPos + 52, this.topPos + 184, 0, 0, 9, 10, 9, 10);
		}
		if (GunroomIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 4, this.topPos + 4, 0, 0, 19, 19, 19, 19);
		}
		if (HoSIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 4, this.topPos + 25, 0, 0, 19, 19, 19, 19);
		}
		if (BrigIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 4, this.topPos + 46, 0, 0, 19, 19, 19, 19);
		}
		if (SecurityIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 4, this.topPos + 67, 0, 0, 19, 19, 19, 19);
		}
		if (DetectiveIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 4, this.topPos + 88, 0, 0, 19, 19, 19, 19);
		}
		if (PNTIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 4, this.topPos + 109, 0, 0, 19, 19, 19, 19);
		}
		if (CrioIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 4, this.topPos + 130, 0, 0, 19, 19, 19, 19);
		}
		if (CEIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 84, this.topPos + 4, 0, 0, 19, 19, 19, 19);
		}
		if (AtmosIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 84, this.topPos + 25, 0, 0, 19, 19, 19, 19);
		}
		if (IngeneerIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 84, this.topPos + 46, 0, 0, 19, 19, 19, 19);
		}
		if (OutIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 84, this.topPos + 67, 0, 0, 19, 19, 19, 19);
		}
		if (QmIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 84, this.topPos + 88, 0, 0, 19, 19, 19, 19);
		}
		if (UtilizatIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 84, this.topPos + 109, 0, 0, 19, 19, 19, 19);
		}
		if (SupplyDeportamentIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 84, this.topPos + 130, 0, 0, 19, 19, 19, 19);
		}
		if (CMOIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 169, this.topPos + 4, 0, 0, 19, 19, 19, 19);
		}
		if (ChemistryIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 169, this.topPos + 25, 0, 0, 19, 19, 19, 19);
		}
		if (MedicalIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 169, this.topPos + 46, 0, 0, 19, 19, 19, 19);
		}
		if (RDIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 169, this.topPos + 67, 0, 0, 19, 19, 19, 19);
		}
		if (ScientistIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 169, this.topPos + 88, 0, 0, 19, 19, 19, 19);
		}
		if (TechnicalIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 169, this.topPos + 109, 0, 0, 19, 19, 19, 19);
		}
		if (ChurchIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 169, this.topPos + 130, 0, 0, 19, 19, 19, 19);
		}
		if (HoPIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 254, this.topPos + 4, 0, 0, 19, 19, 19, 19);
		}
		if (ServiceIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 254, this.topPos + 25, 0, 0, 19, 19, 19, 19);
		}
		if (KitchenIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 254, this.topPos + 46, 0, 0, 19, 19, 19, 19);
		}
		if (GidroponicIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 254, this.topPos + 67, 0, 0, 19, 19, 19, 19);
		}
		if (BarIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 254, this.topPos + 88, 0, 0, 19, 19, 19, 19);
		}
		if (TeatreIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 254, this.topPos + 109, 0, 0, 19, 19, 19, 19);
		}
		if (CleanerIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 254, this.topPos + 130, 0, 0, 19, 19, 19, 19);
		}
		if (CapitanIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 334, this.topPos + 4, 0, 0, 19, 19, 19, 19);
		}
		if (CommandIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 334, this.topPos + 25, 0, 0, 19, 19, 19, 19);
		}
		if (BlueShIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 334, this.topPos + 46, 0, 0, 19, 19, 19, 19);
		}
		if (UridicIDCLockGUIProcedure.execute(entity)) {
			guiGraphics.blit(RenderPipelines.GUI_TEXTURED, ResourceLocation.parse("ssc_14:textures/screens/lock_gui.png"), this.leftPos + 334, this.topPos + 67, 0, 0, 19, 19, 19, 19);
		}
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
	}

	@Override
	public void init() {
		super.init();
		gun_room = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.gun_room"), this.font).pos(this.leftPos + 5, this.topPos + 5).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "gun_room", value, false);
		}).build();
		this.addRenderableWidget(gun_room);
		HoS = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.HoS"), this.font).pos(this.leftPos + 5, this.topPos + 26).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "HoS", value, false);
		}).build();
		this.addRenderableWidget(HoS);
		Brig = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.Brig"), this.font).pos(this.leftPos + 5, this.topPos + 47).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "Brig", value, false);
		}).build();
		this.addRenderableWidget(Brig);
		Security = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.Security"), this.font).pos(this.leftPos + 5, this.topPos + 68).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "Security", value, false);
		}).build();
		this.addRenderableWidget(Security);
		Detective = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.Detective"), this.font).pos(this.leftPos + 5, this.topPos + 89).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "Detective", value, false);
		}).build();
		this.addRenderableWidget(Detective);
		Blue_Sh = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.Blue_Sh"), this.font).pos(this.leftPos + 335, this.topPos + 47).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "Blue_Sh", value, false);
		}).build();
		this.addRenderableWidget(Blue_Sh);
		CE = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.CE"), this.font).pos(this.leftPos + 85, this.topPos + 5).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "CE", value, false);
		}).build();
		this.addRenderableWidget(CE);
		CMO = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.CMO"), this.font).pos(this.leftPos + 170, this.topPos + 5).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "CMO", value, false);
		}).build();
		this.addRenderableWidget(CMO);
		RD = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.RD"), this.font).pos(this.leftPos + 170, this.topPos + 68).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "RD", value, false);
		}).build();
		this.addRenderableWidget(RD);
		PNT = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.PNT"), this.font).pos(this.leftPos + 5, this.topPos + 110).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "PNT", value, false);
		}).build();
		this.addRenderableWidget(PNT);
		HoP = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.HoP"), this.font).pos(this.leftPos + 255, this.topPos + 5).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "HoP", value, false);
		}).build();
		this.addRenderableWidget(HoP);
		Atmos = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.Atmos"), this.font).pos(this.leftPos + 85, this.topPos + 26).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "Atmos", value, false);
		}).build();
		this.addRenderableWidget(Atmos);
		Ingeneer = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.Ingeneer"), this.font).pos(this.leftPos + 85, this.topPos + 47).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "Ingeneer", value, false);
		}).build();
		this.addRenderableWidget(Ingeneer);
		Qm = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.Qm"), this.font).pos(this.leftPos + 85, this.topPos + 89).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "Qm", value, false);
		}).build();
		this.addRenderableWidget(Qm);
		Utilizat = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.Utilizat"), this.font).pos(this.leftPos + 85, this.topPos + 110).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "Utilizat", value, false);
		}).build();
		this.addRenderableWidget(Utilizat);
		Supply_Deportament = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.Supply_Deportament"), this.font).pos(this.leftPos + 85, this.topPos + 131).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "Supply_Deportament", value, false);
		}).build();
		this.addRenderableWidget(Supply_Deportament);
		Technical = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.Technical"), this.font).pos(this.leftPos + 170, this.topPos + 110).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "Technical", value, false);
		}).build();
		this.addRenderableWidget(Technical);
		Chemistry = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.Chemistry"), this.font).pos(this.leftPos + 170, this.topPos + 26).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "Chemistry", value, false);
		}).build();
		this.addRenderableWidget(Chemistry);
		Medical = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.Medical"), this.font).pos(this.leftPos + 170, this.topPos + 47).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "Medical", value, false);
		}).build();
		this.addRenderableWidget(Medical);
		Scientist = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.Scientist"), this.font).pos(this.leftPos + 170, this.topPos + 89).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "Scientist", value, false);
		}).build();
		this.addRenderableWidget(Scientist);
		Out = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.Out"), this.font).pos(this.leftPos + 85, this.topPos + 68).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "Out", value, false);
		}).build();
		this.addRenderableWidget(Out);
		Crio = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.Crio"), this.font).pos(this.leftPos + 5, this.topPos + 131).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "Crio", value, false);
		}).build();
		this.addRenderableWidget(Crio);
		Capitan = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.Capitan"), this.font).pos(this.leftPos + 335, this.topPos + 5).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "Capitan", value, false);
		}).build();
		this.addRenderableWidget(Capitan);
		Service = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.Service"), this.font).pos(this.leftPos + 255, this.topPos + 26).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "Service", value, false);
		}).build();
		this.addRenderableWidget(Service);
		Kitchen = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.Kitchen"), this.font).pos(this.leftPos + 255, this.topPos + 47).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "Kitchen", value, false);
		}).build();
		this.addRenderableWidget(Kitchen);
		Gidroponic = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.Gidroponic"), this.font).pos(this.leftPos + 255, this.topPos + 68).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "Gidroponic", value, false);
		}).build();
		this.addRenderableWidget(Gidroponic);
		Bar = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.Bar"), this.font).pos(this.leftPos + 255, this.topPos + 89).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "Bar", value, false);
		}).build();
		this.addRenderableWidget(Bar);
		Teatre = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.Teatre"), this.font).pos(this.leftPos + 255, this.topPos + 110).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "Teatre", value, false);
		}).build();
		this.addRenderableWidget(Teatre);
		Cleaner = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.Cleaner"), this.font).pos(this.leftPos + 255, this.topPos + 131).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "Cleaner", value, false);
		}).build();
		this.addRenderableWidget(Cleaner);
		Command = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.Command"), this.font).pos(this.leftPos + 335, this.topPos + 26).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "Command", value, false);
		}).build();
		this.addRenderableWidget(Command);
		Uridic = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.Uridic"), this.font).pos(this.leftPos + 335, this.topPos + 68).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "Uridic", value, false);
		}).build();
		this.addRenderableWidget(Uridic);
		Church = Checkbox.builder(Component.translatable("gui.ssc_14.i_dcode.Church"), this.font).pos(this.leftPos + 170, this.topPos + 131).onValueChange((checkbox, value) -> {
			if (!menuStateUpdateActive)
				menu.sendMenuStateUpdate(entity, 1, "Church", value, false);
		}).build();
		this.addRenderableWidget(Church);
	}
}